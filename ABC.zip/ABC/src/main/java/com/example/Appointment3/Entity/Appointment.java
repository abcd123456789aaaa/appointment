package com.example.Appointment3.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Apx")
public class Appointment {
	
	    @Id
	    @GeneratedValue(strategy=GenerationType.AUTO)
	    private int id;
	    private String patient;
	    private String doctor;
	    private String appointmentType;
	    private String appointmentDate;
	    private String confirmation;
	    
	    public Appointment() {
	    	
	    }

		
		public Appointment(String patient, String doctor, String appointmentType, String appointmentDate,
				String confirmation) {
			super();
			this.patient = patient;
			this.doctor = doctor;
			this.appointmentType = appointmentType;
			this.appointmentDate = appointmentDate;
			this.confirmation = confirmation;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
    			this.id = id;
		}
		public String getPatient() {
			return patient;
		}
		public void setPatient(String patient) {
			this.patient = patient;
		}
		public String getDoctor() {
			return doctor;
		}
		public void setDoctor(String doctor) {
			this.doctor = doctor;
		}
		public String getAppointmentType() {
			return appointmentType;
		}
		public void setAppointmentType(String appointmentType) {			this.appointmentType = appointmentType;
		}
		public String getAppointmentDate() {
			return appointmentDate;
		}
		public void setAppointmentDate(String appointmentDate) {
			this.appointmentDate = appointmentDate;
		}
 	public String getConfirmation() {
			return confirmation;
		}
		public void setConfirmation(String confirmation) {
			this.confirmation = confirmation;
	}

}
