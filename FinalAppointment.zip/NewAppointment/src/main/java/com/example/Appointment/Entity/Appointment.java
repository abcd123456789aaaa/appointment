//package com.example.Appointment.Entity;
//
//import javax.persistence.Entity;
//
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//
//
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="Apx")
//public class Appointment {
//	
//	    @Id
//	    @GeneratedValue(strategy=GenerationType.AUTO)
//	    private int id;
//	    private String patient;
//	    private String doctor;
//	    private String appointmentType;
//	    private String appointmentDate;
//	    private String Confirmation;
//	    
//	    
//		public Appointment(int id, String patient, String doctor, String appointmentType, String appointmentDate,
//				String confirmation) {
//			super();
//			this.id = id;
//			this.patient = patient;
//			this.doctor = doctor;
//			this.appointmentType = appointmentType;
//			this.appointmentDate = appointmentDate;
//			Confirmation = confirmation;
//		}
//		public int getId() {
//			return id;
//		}
//		public void setId(int id) {
//			this.id = id;
//		}
//		public String getPatient() {
//			return patient;
//		}
//		public void setPatient(String patient) {
//			this.patient = patient;
//		}
//		public String getDoctor() {
//			return doctor;
//		}
//		public void setDoctor(String doctor) {
//			this.doctor = doctor;
//		}
//		public String getAppointmentType() {
//			return appointmentType;
//		}
//		public void setAppointmentType(String appointmentType) {
//			this.appointmentType = appointmentType;
//		}
//		public String getAppointmentDate() {
//			return appointmentDate;
//		}
//		public void setAppointmentDate(String appointmentDate) {
//			this.appointmentDate = appointmentDate;
//		}
//		public String getConfirmation() {
//			return Confirmation;
//		}
//		public void setConfirmation(String confirmation) {
//			Confirmation = confirmation;
//		}
//
//}
