package com.example.Appointment.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.example.Appointment.Entity.Appointment;
//import com.example.Appointment.Service.AppointmentService;



@RestController
public class AppointmentController {
	
	//@Autowired
	//private AppointmentService appointmentService;

    @GetMapping("/")
    public String index() {
        return "Greetings from Spring Boot!";
    }

//	@RequestMapping("/doctors")
//	public List<Appointment> getAllAppointments(){
//		return appointmentService.getAllAppointments();
//	}
//	
//	@RequestMapping(method=RequestMethod.POST,value="/appointments")
//	public void addAppointment(@RequestBody Appointment appointment)
//	{
//		appointmentService.addAppointment(appointment);
//	}
//	
//	@RequestMapping(method=RequestMethod.PUT,value="/appointments/{id}")
//	public void updateAppointment(@PathVariable String id,@RequestBody Appointment appointment)
//	{
//		appointmentService.updateAppointment(id, appointment);
//	}
//	
	/*public void DeleteAppointment(@PathVariable int id)
	{
		appointmentService.deleteAppointment(id);
	}*/

}
