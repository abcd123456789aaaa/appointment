package com.example.Appointment.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.Appointment.Service.AppointmentService;



@RestController
public class AppointmentController {
	
	

	
	@Autowired
	private AppointmentService appointmentService;

//	@RequestMapping("/doctors")
//	public List<Appointment> getAllAppointments(){
//		
//		return appointmentService.getAllAppointments();
//	}
//	
//	@RequestMapping(method=RequestMethod.POST,value="/appointments")
//	public void addAppointment(@RequestBody Appointment appointment)
//	{
//		appointmentService.addAppointment(appointment);
//	}
//	
//	@RequestMapping(method=RequestMethod.PUT,value="/appointments/{id}")
//	public void updateAppointment(@PathVariable String id,@RequestBody Appointment appointment)
//	{
//		appointmentService.updateAppointment(id, appointment);
//	}
//	
	/*public void DeleteAppointment(@PathVariable int id)
	{
		appointmentService.deleteAppointment(id);
	}*/

}
