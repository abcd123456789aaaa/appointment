package com.example.Appointment3.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Appointment3.Entity.Appointment;
import com.example.Appointment3.Repository.AppointmentRepository;

@Service("appointmentService")
public class AppointmentService {

	@Autowired
	AppointmentRepository appointmentRepository;

	public List<Appointment> getAllAppointments() {
		List<Appointment> appointments = new ArrayList<>();
		appointmentRepository.findAll().forEach(appointments::add);
		return appointments;
	}

	public void addAppointment(Appointment appointment) {
		appointmentRepository.save(appointment);

	}

	public void updateAppointment(String id, Appointment appointment) {
		appointmentRepository.save(appointment);

	}

	public void deleteAppointment(int id) {
		appointmentRepository.deleteById(id);

	}

}
