package com.example.Appointment3.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.Appointment3.Entity.Appointment;


@Repository
public interface AppointmentRepository extends CrudRepository<Appointment,Integer> {
	List<Appointment> findAll();
}
